# CHOP & SHOP GH — Ghanaian Virtual Marketplace Prototype

Open `index.html` in a modern browser to run the prototype.

Included:
- Marketplace and product search
- Foodstuff/grocery marketplace
- Shopping basket and checkout demo
- Order tracking
- Market Run
- Ghanaian recipe-to-basket feature
- Farm-to-Home
- Seller registration and dashboard
- Chop Wallet
- Chop Points
- Chop Pass
- ChopBot shopping assistant
- GH Deals
- Social Marketplace
- Market Map
- Family shopping list
- Profile, settings, notifications and help pages
- Responsive mobile-friendly design
- Ghanaian visual identity using forest green, warm gold, terracotta and cream

This is a front-end prototype. Payments, maps, authentication, real courier APIs and a production database would need backend/integration work.
