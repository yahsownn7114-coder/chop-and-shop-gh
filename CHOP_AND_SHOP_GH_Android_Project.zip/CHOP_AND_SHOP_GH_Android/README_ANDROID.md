# CHOP & SHOP GH — Android App Project

This package wraps the existing CHOP & SHOP GH web prototype in an Android application using a WebView. The app opens its bundled pages locally, so the demo can be browsed offline. Cart and other browser-local demo data use WebView local storage.

## Build an installable APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `CHOP_AND_SHOP_GH_Android` folder.
4. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
5. Use **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
6. When the build finishes, choose **Locate** to find the APK. Transfer it to your Android phone and install it. Android may ask you to allow installation from that file manager.

## Important
- This is an Android Studio source project, not a precompiled APK.
- This is still a functional front-end prototype. Real accounts, live product inventory, payment processing, maps/GPS, courier dispatch, and a production database are not connected yet.
- Payment and delivery providers listed in the business plan are possibilities only; partnerships and integration need to be arranged separately.
- Before public release, add a privacy policy, production backend, secure authentication, validated payments, error handling, and appropriate testing.


## Optional cloud build (requires a Git repository)
A `codemagic.yaml` workflow is included for a cloud build. Codemagic expects the project to be available from a connected Git repository (for example GitHub); it does not build this ZIP merely by uploading it. Once the project files are in a repository, connect that repository in Codemagic and start the `CHOP & SHOP GH Android APK` workflow. Download the generated APK from the build artifacts if the build succeeds.
